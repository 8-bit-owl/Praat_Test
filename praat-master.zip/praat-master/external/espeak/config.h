
#define PACKAGE_VERSION "1.49.3-dev"

